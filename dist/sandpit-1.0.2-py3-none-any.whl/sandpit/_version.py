"""
_version.py

Created on 24 Jul 2022

:author: semuadmin
:copyright: SEMU Consulting © 2022
:license: BSD 3-Claus
"""

__version__ = "1.0.2"
