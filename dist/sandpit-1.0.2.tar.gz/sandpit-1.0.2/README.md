sandpit
=======

[Current Status](#currentstatus) | [Author & License](#author)

** NOTHING TO SEE HERE - MOVE ALONG **

Testing sandpit for VS Code and GitHub Actions Continuous Integration workflows,
build toolchains and other shiz.

## <a name="currentstatus">Current Status</a>

![Release](https://img.shields.io/github/v/release/semuadmin/sandpit)
![Build](https://img.shields.io/github/actions/workflow/status/semuadmin/sandpit/main.yml)
![Codecov](https://img.shields.io/codecov/c/github/semuadmin/sandpit)
![Release Date](https://img.shields.io/github/release-date-pre/semuadmin/sandpit)
![Last Commit](https://img.shields.io/github/last-commit/semuadmin/sandpit)
![Contributors](https://img.shields.io/github/contributors/semuadmin/sandpit.svg)
![Open Issues](https://img.shields.io/github/issues-raw/semuadmin/sandpit)


## <a name="author">Author & License Information</a>

![GitHub License](https://img.shields.io/github/license/semuadmin/sandpit)
