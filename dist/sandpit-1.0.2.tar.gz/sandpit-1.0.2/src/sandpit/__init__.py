"""
__init__.py

Created on 24 Jul 2022

:author: semuadmin
:copyright: SEMU Consulting © 2022
:license: BSD 3-Clause
"""

from sandpit._version import __version__
from sandpit.calculate import *

version = __version__  # pylint: disable=invalid-name
